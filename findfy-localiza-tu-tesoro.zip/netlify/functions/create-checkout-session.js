// /.netlify/functions/create-checkout-session
// Requiere STRIPE_SECRET_KEY en variables de entorno (Netlify/Render/Vercel).
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

exports.handler = async function(event, context) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }
  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      payment_method_types: ['card'],
      line_items: [
        {
          price_data: {
            currency: 'eur',
            product_data: { name: 'Plan Premium - Localiza tu Tesoro' },
            unit_amount: 990
          },
          quantity: 1
        }
      ],
      success_url: `${process.env.SITE_URL || 'http://localhost:8888'}/?status=success`,
      cancel_url: `${process.env.SITE_URL || 'http://localhost:8888'}/?status=cancel`
    });
    return {
      statusCode: 200,
      body: JSON.stringify({ url: session.url })
    };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
